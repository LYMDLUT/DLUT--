# -*- coding: UTF-8 -*-
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
plt.rc('font',family='MicroSoft YaHei',weight='bold')



u0 = 4*np.pi*10**(-7)
e0 = 1/(36*np.pi)*10**(-9)
u = u0
e = e0
f  = 9.375*10**9
w = 2*np.pi*f
a = 22.86/1000
b = 10.16/1000
H10 = 1
c = 299792458 
beta = w/c
k = w *np.sqrt(u*e)
lambda1 = 2*np.pi*c/w
d  = 15
lc=2*a             #TE10截止波长
l0=(3*10^8)/f

'''
##############1
fig, ax = plt.subplots()
def animate(z):
    x = np.arange(-a,0,lambda1/10)
    #for z  in np.arange(0,0.1,0.001):
    for t in np.arange(0,0.0001,0.0001):
        Hx = beta*a/np.pi*H10*np.sin(np.pi*x/a)*np.cos(w*t-beta*z+np.pi/2)
        plt.plot(x , Hx)
        #plt.axis([ -a, 0 , -inf , inf])
        plt.xlim( -a, 0)
        #plt.ylim(float("-inf"),float("inf"))
        plt.title('波导内Hx强度波形')
        plt.xlabel('宽边x方向')

# 参数：每一帧返回的图像实例，绘制每一帧的函数，动画长度，
#       是否启用一个函数来刷新，如果不设置则用第二个参数的第一帧刷新
#       帧率？貌似是
#       是否刷新所有的点
ani = animation.FuncAnimation(fig,animate,np.arange(0,0.1,0.001), interval=50, blit=False)
#animate()
plt.show()
'''

'''
#########################2
#for z =0 : 0.001 : 0.1
fig, ax = plt.subplots()
def animate(z):
    x = np.arange(-a,0,lambda1/10)
    for t in np.arange(0,0.0001,0.0001):
        Ey = w*u*a/np.pi*H10*np.sin(np.pi*x/a)*np.cos(w*t-beta*z-np.pi/2);
        plt.plot(x , Ey);
        #axis([ -a , 0 , -inf , inf])
        plt.xlim( -a, 0)
        plt.title('波导内Ey强度波形');
        plt.xlabel('宽边x方向');
ani = animation.FuncAnimation(fig,animate,np.arange(0,0.1,0.001), interval=50, blit=False)
plt.show()
'''
'''
#################3
fig, ax = plt.subplots()
def animate(z):
    x = np.arange(-a,0,lambda1/10)
    for t in np.arange(0,0.0001,0.0001):
        Hz = H10*np.cos(np.pi*x/a)*np.cos(w*t-beta*z);
        plt.plot(x , Hz);
        #axis([ -a , 0 , -inf , inf]);
        plt.xlim( -a, 0)
        plt.title('波导内Hz强度波形');
        plt.xlabel('宽边x方向');
ani = animation.FuncAnimation(fig,animate,np.arange(0,0.1,0.001), interval=50, blit=False)
plt.show()
'''
'''
#####################################静图
lg=l0/((1-(l0/lc)**2)**0.5)
c=lg
B=2*np.pi/lg
x=np.arange(0,a,a/d)
y=np.arange(0,b,b/d)
z=np.arange(0,c,c/d)
[x1,y1,z1]=np.meshgrid(x,y,z)
####################################
'''
'''
ex=np.zeros(np.size(x1))
ez=np.zeros(np.size(z1))
#for t in np.arange(0,5*10**(-8),10**(-9)):
t=0
ey=w*u*a*H10*np.sin(np.pi/a*x1)*np.sin(w*t-B*z1)/np.pi*0.000000000002
fig = plt.figure()
#ax = Axes3D(fig)
ax = fig.gca(projection='3d')
ax.quiver3D(z1,x1,y1,0,0,ey,color='r')#,color='deepskyblue', width=0.005, scale=30,length=0.00000000001,pivot = 'middle'
#ax.scatter(z1,x1,y1, color = 'black')
#for x,y,z,u,v,w in zip(z1,x1,y1,ez,ex,ey):
    #ax.quiver(x, y, z, u, v, w,color='r',length=0.0000000001)
#ax.quiver3D(z1,x1,y1,ez,ex,ey,color='deepskyblue',normalize=False)
#hold on
hx=(-1)*B*a*H10*np.sin(np.pi/a*x1)*np.sin(w*t-B*z1)/np.pi
hy=np.zeros(np.size(y1))
hz=H10*np.cos(np.pi/a*x1)*np.cos(w*t-B*z1)
for x,y,z,u,v,w in zip(z1,x1,y1,hz,hx,hy):
    ax.quiver(x, y, z, u, v, w,color='deepskyblue',length=0.00000000008)
#ax.quiver3D(z1,x1,y1,hz,hx,0,color='r')
ax.set_title('波导管内电磁场分布图')
#ax.axis('equal')
ax.set_xlabel('传输方向')
ax.set_ylabel('波导宽边a')
ax.set_zlabel('波导窄边b')
#hold off
plt.show()
'''
'''
#######################动态
#for t=0:10^(-9):5*10^(-8)
fig = plt.figure()
ax = fig.gca(projection='3d')
def animate(t):
    
    
    ###############
    u0 = 4*np.pi*10**(-7)
    e0 = 1/(36*np.pi)*10**(-9)
    u = u0
    e = e0
    f  = 9.375*10**9
    w = 2*np.pi*f
    a = 22.86/1000
    b = 10.16/1000
    H10 = 1
    c = 299792458 
    beta = w/c
    k = w *np.sqrt(u*e)
    lambda1 = 2*np.pi*c/w
    d  = 15
    lc=2*a             #TE10截止波长
    l0=(3*10^8)/f
    2
    
    #############
    ex=np.zeros(np.size(x1))
    ey=w*u*a*H10*np.sin(np.pi/a*x1)*np.sin(w*t-B*z1)/np.pi*0.000000000002
    ez=np.zeros(np.size(z1))
    #fig = plt.figure()
    #ax = fig.gca(projection='3d')
    ax.quiver3D(z1,x1,y1,0,0,ey,color='r')
    #set(h,'maxheadsize',0);
    hx=(-1)*B*a*H10*np.sin(np.pi/a*x1)*np.sin(w*t-B*z1)/np.pi
    hy=np.zeros(np.size(y1))
    hz=H10*np.cos(np.pi/a*x1)*np.cos(w*t-B*z1)
    for x,y,z,u,v,w in zip(z1,x1,y1,hz,hx,hy):
        ax.quiver(x, y, z, u, v, w,color='deepskyblue',length=0.00000000008)
    #set(h,'maxheadsize',0);
    #ax.set_title(['波导管内电磁场分布图','t=',num2str(t),'s']);
    #axis equal
    ax.set_xlabel('传输方向')
    ax.set_ylabel('波导宽边a')
    ax.set_zlabel('波导窄边b')
    
    




#animate(0)
ani = animation.FuncAnimation(fig,animate,np.arange(0,5*10**(-8),10**(-9)), interval=50, blit=False)
plt.show()
'''
'''
#########1
x = a/2
t = 0.0001
z = np.arange(0,lambda1,lambda1/d)
hx = beta*a/np.pi*H10*np.sin(np.pi*x/a)*np.cos(w*t-beta*z+np.pi/2)
#fig = plt.figure()
#fig, ax = plt.subplots()
plt.plot(z,hx,c='b')
plt.title('t = 0.0001时，宽边x = 11mm纵切，波导内Hx波形')
plt.xlabel('传输方向z')
plt.show()
'''
'''
#########2
x = a/2
t = 0.0001
z = np.arange(0,lambda1,lambda1/d)
ey = w * u * a / np.pi * H10 * np.sin(np.pi * x / a) * np.cos(w * t - beta * z - np.pi / 2)
plt.plot(z,ey,c='r')
plt.title('t=0.0001s时,宽边x=11mm纵切，波导内Ey波形')
plt.xlabel('传输方向z')
plt.show()
'''
'''
###########3
z = 3
t = 0.0001
x = np.arange(0,lambda1,lambda1/d)
hz = H10 *np.cos(np.pi * x / a) * np.cos(w * t - beta * z)
plt.plot(x,hz,c='y')
plt.title('t=0.0001s,传播方向z=3横断面处，波导内Hz强度波形')
plt.xlabel('宽边x方向')
plt.show()
'''



#########################################
'''
############################surf
lg = lambda1 / ((1 - (lambda1 / lc)**2)**0.5)
B = 2 * np.pi / lg
w = 2 * np.pi * f
t = 1
x = np.arange(0,a,a/d)
z= np.arange(0,lg,lg/d)
[x2,z2] = np.meshgrid(x,z)
Ey = w*u*a*H10*np.sin(np.pi/a*x2)*np.sin(w*t-B*z2)/np.pi
#print(Ey)
fig = plt.figure()
#ax = fig.gca(projection='3d')
ax = Axes3D(fig)
ax.plot_surface(x2,z2,Ey)
ax.set_title('任意x处,Ey电场大小')
ax.set_ylabel('传输方向z')
ax.set_xlabel('波导宽边a')
ax.set_zlabel('波导窄边b')
plt.show()
'''